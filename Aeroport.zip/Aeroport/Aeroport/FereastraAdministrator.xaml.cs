﻿using Aeroport.Model;
using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for FereastraAdministrator.xaml
    /// </summary>
    public partial class FereastraAdministrator : Window, interfataComuna, setters
    {
        SearchFlyPresenter flyPresenter;
        public FereastraAdministrator()
        {
            InitializeComponent();
            this.flyPresenter = new SearchFlyPresenter(this,this);
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            flyPresenter.getSearchedZbor();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.Show();
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Zboruri zboruri = new Zboruri();
            this.Close();
            zboruri.Show();
        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            ActiuniAdministrator admin = new ActiuniAdministrator();
            this.Close();
            admin.Show();
        }
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            ListaUseri listaUseri = new ListaUseri();
            this.Close();
            listaUseri.Show();
        }
        public string GetDataIntoarcere()
        {
            return intoarcereTxt.Text;
        }
        public string GetDataPlecare()
        {
            return plecareTxt.Text;
        }
        public string GetFrom()
        {
            return fromTxt.Text;
        }
        public string GetNumarPasageri()
        {
            return pasageriTxt1.Text;
        }
        public string GetTo()
        {
            return toTxt.Text;
        }

        public void mesajAeroportInvalid()
        {
            MessageBox.Show("Aeroport invalid!");
        }

        public void mesajDestinatieInvalida()
        {
            MessageBox.Show("Destinatie invalid!");
        }

        public void mesajNrPasageriInvalid()
        {
            MessageBox.Show("Numar pasageri invalid!");
        }

        public void mesajDataPlecareInvalida()
        {
            MessageBox.Show("Data plecare invalid!");
        }

        public void mesajDataRevenireInvalida()
        {
            MessageBox.Show("Data revenire invalid!");
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista este goala!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajGasireSucces()
        {
            MessageBox.Show("Exista zbor!");
        }

        public void mesajGasireEsec()
        {
            MessageBox.Show("Nu exista zbor!");
        }

        public void setDestinatie(string destinatie)
        {
            this.toTxt.Text = destinatie;
        }

        public void SetAeroport(string aeroport)
        {
            this.fromTxt.Text = aeroport;
        }

        public void setDataPlecare(string dataPlecare)
        {
            this.plecareTxt.Text = dataPlecare;
        }

        public void setDataRevenire(string dataRevenire)
        {
            this.intoarcereTxt.Text = dataRevenire;
        }

        public void setNumarPasageri(string nrPasageri)
        {
            this.pasageriTxt1.Text = nrPasageri;
        }
    }
}
