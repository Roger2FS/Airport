﻿using Aeroport.Model;
using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for Zboruri.xaml
    /// </summary>
    public partial class Zboruri : Window, IListaZbor
    {
        private ListaZborPresenter<IListaZbor> zborPresenter;
        public Zboruri()
        {
            InitializeComponent();
            this.zborPresenter = new ListaZborPresenter<IListaZbor>(this);
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.zborPresenter.afisareLista();
        }

        public DataGrid getGrid()
        {
            return this.gridView1 as DataGrid;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            this.Close();
            main.Show();
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista este goala!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }
    }
}
