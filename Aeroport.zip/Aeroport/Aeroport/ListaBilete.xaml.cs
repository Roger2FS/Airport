﻿using Aeroport.Model;
using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Aeroport.ListaUseri;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for ListaBilete.xaml
    /// </summary>
    public partial class ListaBilete : Window, IListaBilet
    {
        private ListaBiletPresenter ticket;
        public ListaBilete()
        {
            InitializeComponent();
            this.ticket = new ListaBiletPresenter(this);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            FereastraAngajat fereastraAngajat = new FereastraAngajat();
            this.Close();
            fereastraAngajat.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.ticket.afisareLista();
        }

        public DataGrid getGrid()
        {
            return this.gridView1 as DataGrid;
        }
        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista goala!");
        }
    }
}
