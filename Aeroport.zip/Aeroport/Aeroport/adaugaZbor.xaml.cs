﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for adaugaZbor.xaml
    /// </summary>
    public partial class AdaugaZbor : Window , IadaugaZbor, interfataComuna
    {
        private ZborPresenter<IadaugaZbor, interfataComuna> zborPresenter;
        public AdaugaZbor()
        {
            InitializeComponent();
            this.zborPresenter = new ZborPresenter<IadaugaZbor, interfataComuna>(this,this);
        }

        public string GetDataIntoarcere()
        {
            return dataRevenire.Text;
        }

        public string GetDataPlecare()
        {
            return dataPlecare.Text;
        }

        public string GetDurataZbor()
        {
            return durataBTN.Text;
        }

        public string GetFrom()
        {
            return aeroportBtn.Text;
        }

        public string GetModalitate()
        {
            return modalitateBTN.Text;
        }

        public string GetNumarPasageri()
        {
            return locuri.Text;
        }

        public string GetNumarZbor()
        {
            return nrZborBTN.Text;
        }

        public string GetPret()
        {
            return pretBTN.Text;
        }

        public string GetTo()
        {
            return aeroportBtn.Text;
        }

        public void mesajAeroportInvalid()
        {
            MessageBox.Show("Aeroport invalid!");
        }

        public void mesajDataPlecareInvalida()
        {
            MessageBox.Show("Data plecare invalida!");
        }

        public void mesajDataRevenireInvalida()
        {
            MessageBox.Show("Data revenire invalida!");
        }

        public void mesajDateInvalide()
        {
            MessageBox.Show("Date invalide!");
        }

        public void mesajDestinatieInvalida()
        {
            MessageBox.Show("Destinatie invalida!");
        }

        public void mesajDurataInvalida()
        {
            MessageBox.Show("Durata zbor invalida!");
        }

        public void mesajEsec()
        {
            MessageBox.Show("Nu s-a putut adauga zborul!");
        }

        public void mesajEsecModificare()
        {
            MessageBox.Show("Nu a putut fi modificat zborul!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajGasireEsec()
        {
            MessageBox.Show("Zborul nu a fost gasit!");
        }

        public void mesajGasireSucces()
        {
            MessageBox.Show("Zborul a fost gasit!");
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Nu exista zboruri!");
        }

        public void mesajModalitateInvalida()
        {
            MessageBox.Show("Modalitate invalida!");
        }

        public void mesajNrPasageriInvalid()
        {
            MessageBox.Show("Numar pasageri invalid!");
        }

        public void mesajNrZborInvalid()
        {
            MessageBox.Show("Numar zbor invalid!");
        }

        public void mesajPretInvalid()
        {
            MessageBox.Show("Pretul invalid!");
        }

        public void mesajStergereEsec()
        {
            MessageBox.Show("Zborul nu a putut fi sters!");
        }

        public void mesajStergereSucces()
        {
            MessageBox.Show("Zborul a fost sters!");
        }

        public void mesajSucces()
        {
            MessageBox.Show("Zborul a fost adaugat cu succes!");
        }

        public void mesajSuccesModificare()
        {
            MessageBox.Show("Modificarea a avut succes!");
        }

        public void SetAeroport(string aeroport)
        {
            this.aeroportBtn.Text = aeroport;
        }

        public void setDataPlecare(string value)
        {
            this.dataPlecare.Text = value;
        }

        public void setDataRevenire(string value)
        {
            this.dataRevenire.Text = value;
        }

        public void setDestinatie(string destinatie)
        {
            this.destinatieBTN.Text = destinatie;
        }

        public void SetDurataZbor(string durataZbor)
        {
            this.durataBTN.Text = durataZbor;
        }

        public void SetModalitate(string modalitate)
        {
            this.modalitateBTN.Text = modalitate;   
        }

        public void setNumarPasageri(string pasageri)
        {
            this.locuri.Text = pasageri;
        }

        public void SetNumarZbor(string numarZbor)
        {
            this.nrZborBTN.Text = numarZbor;
        }

        public void SetPret(string pret)
        {
            this.pretBTN.Text = pret;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.zborPresenter.AddFly();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ActiuniAngajat actiuni = new ActiuniAngajat();
            this.Close();
            actiuni.Show();
        }

        private void destinatieBTN_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        public DataGrid getGrid()
        {
            throw new NotImplementedException();
        }
    }
}
