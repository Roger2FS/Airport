﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for adaugaUser.xaml
    /// </summary>
    public partial class AdaugaUser : Window, IadaugaUser
    {
        UserPresenter user;
        public AdaugaUser()
        {
            InitializeComponent();
            this.user = new UserPresenter(this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ActiuniAdministrator admin = new ActiuniAdministrator();
            this.Close();
            admin.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.user.AddUser();
        }

        public string getParola()
        {
            return parola.Text;
        }

        public string getTipUtilizator()
        {
            return tipUser.Text;
        }

        public string getUtilizator()
        {
            return username.Text;
        }

        public void mesajEsec()
        {
            MessageBox.Show("Userul nu a putut fi adaugat!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajIdInvalid()
        {
            MessageBox.Show("Id invalid!");
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista este goala!");
        }

        public void mesajParolaInvalida()
        {
            MessageBox.Show("Parola este invalida!");
        }

        public void mesajStergereEsec()
        {
            MessageBox.Show("Stergerea nu a avut loc!");
        }

        public void mesajStergereSucces()
        {
            MessageBox.Show("Stergerea a avut loc!");
        }

        public void mesajSucces()
        {
            MessageBox.Show("Userul a fost adaugat cu succes!");
        }

        public void mesajSuccesModificare()
        {
            MessageBox.Show("Modificare cu succes!");
        }

        public void mesajTipUserInvalida()
        {
            MessageBox.Show("Tip user invalid!");
        }

        public void mesajUtilizatorInvalid()
        {
            MessageBox.Show("Userul este invalid!");
        }

        public void setParola(string parola)
        {
            this.parola.Text = parola;
        }

        public void setTipUtilizator(string tipUtilizator)
        {
            this.tipUser.Text = tipUtilizator;
        }

        public void setUtilizator(string utilizator)
        {
            this.username.Text = utilizator;
        }

        public string getID()
        {
            throw new NotImplementedException();
        }

        public void SetId(int id)
        {
            throw new NotImplementedException();
        }

        public DataGrid getGrid()
        {
            throw new NotImplementedException();
        }
    }
}
