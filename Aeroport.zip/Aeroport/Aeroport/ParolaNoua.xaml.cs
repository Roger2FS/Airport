﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for ParolaNoua.xaml
    /// </summary>
    public partial class ParolaNoua : Window, ISchimbaParola
    {
        private SchimbaParolaPresenter schimba;
        public ParolaNoua()
        {
            InitializeComponent();
            this.schimba = new SchimbaParolaPresenter(this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.schimba.updateParola();
        }
        public string getParola()
        {
            return parolaNouaTxt.Password.ToString(); 
        }

        public string getUtilizator()
        {
            return utilizatorSchimbaParola.Text;
        }

        public void setParola(string parola)
        {
            this.parolaNouaTxt.Password = parola;
        }

        public void setUtilizator(string utilizator)
        {
            this.utilizatorSchimbaParola.Text = utilizator;
        }
        public void Succes()
        {
            MessageBox.Show("Parola a fost schimbata cu succes!");
        }

        public void Esec()
        {
            MessageBox.Show("Parola nu a putut fi schimbata!");
        }

        public void mesajNuExistaUtilizator()
        {
            MessageBox.Show("Utilizatorul nu exista!");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.Show();
        }
    }
}
