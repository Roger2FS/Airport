﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for modificaUser.xaml
    /// </summary>
    public partial class ModificaUser : Window, IadaugaUser
    {
        UserPresenter user;
        public ModificaUser()
        {
            InitializeComponent();
            this.user = new UserPresenter(this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ActiuniAdministrator admin = new ActiuniAdministrator();
            this.Close();
            admin.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.user.UpdateUser();
        }

        public string getID()
        {
            return id.Text;
        }

        public string getParola()
        {
            return parola.Text;
        }

        public string getTipUtilizator()
        {
            return tipUser.Text;
        }

        public string getUtilizator()
        {
            return username.Text;
        }

        public void mesajEsec()
        {
            MessageBox.Show("Modificarea nu a putut fi efectuata!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajIdInvalid()
        {
            MessageBox.Show("ID invalid!");
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista goala!");
        }

        public void mesajParolaInvalida()
        {
            MessageBox.Show("Parola invalida!");
        }

        public void mesajStergereEsec()
        {
            MessageBox.Show("Stergerea nu a avut loc!");
        }

        public void mesajStergereSucces()
        {
            MessageBox.Show("Stergerea a avut loc!");
        }

        public void mesajSucces()
        {
            MessageBox.Show("Actiunea a fost efectuata cu succes!");
        }

        public void mesajSuccesModificare()
        {
            MessageBox.Show("Modificarea a fost efectuata cu succes!");
        }

        public void mesajTipUserInvalida()
        {
            MessageBox.Show("Tip user invalid!");
        }

        public void mesajUtilizatorInvalid()
        {
            MessageBox.Show("Username invalid!");
        }

        public void SetId(int id)
        {
            throw new NotImplementedException();
        }

        public void setParola(string parola)
        {
            throw new NotImplementedException();
        }

        public void setTipUtilizator(string tipUtilizator)
        {
            throw new NotImplementedException();
        }

        public void setUtilizator(string utilizator)
        {
            throw new NotImplementedException();
        }

        public DataGrid getGrid()
        {
            throw new NotImplementedException();
        }
    }
}
