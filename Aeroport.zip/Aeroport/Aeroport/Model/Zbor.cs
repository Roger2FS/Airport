﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Model
{
    public class Zbor
    {
        protected string aeroport;
        protected string destinatie;
        protected string numarZbor;
        protected string pret;
        protected string durata;
        protected string modalitate;
        protected string dataPlecare;
        protected string dataRevenire;
        protected int locuri;
        public Zbor(string aeroport, string destinatie, string numarZbor, string pret, string durata, string modalitate, string dataPlecare, string dataRevenire, int locuri)
        {
            this.aeroport = aeroport;
            this.destinatie = destinatie;
            this.numarZbor = numarZbor;
            this.pret = pret;
            this.durata = durata;
            this.modalitate = modalitate;
            this.dataPlecare = dataPlecare;
            this.dataRevenire = dataRevenire;
            this.locuri = locuri;
        }

        public string Airport
        {
            get { return aeroport; }
            set { aeroport = value; }
        }

        public string Destinatie { 
            get { return destinatie; } 
            set { destinatie = value; } 
        }

        public string NumarZbor
        {
            get { return numarZbor; } 
            set { numarZbor = value; }
        }

        public string Pret
        {
            get { return pret; }
            set { pret = value; }
        }

        public string Durata
        {
            get { return durata; }
            set { durata = value; }
        }

        public string Modalitate
        {
            get { return modalitate; }
            set { modalitate = value; }
        }

        public string DataPlecare
        {
            get { return dataPlecare; }
            set { dataPlecare = value; }
        }
        public string DataRevenire
        {
            get { return dataRevenire; }
            set { dataRevenire = value; }
        }
        public int Locuri
        {
            get { return locuri; }
            set { locuri = value; }
        }
        public override string ToString()
        {
            string s = "Aeroportul: " + this.aeroport;
            s += " Destinatia: " + this.destinatie;
            s += " Numar zbor: " + this.numarZbor;
            s += " Pretul: " + this.pret;
            s += " Durata: " + this.durata;
            s += " Modalitatea: " + this.modalitate;
            s += " Data Plecare: " + this.dataPlecare;
            s += " Data Intoarcere: " + this.dataRevenire;
            s += " Locuri: " + this.locuri;

            return s;
        }
    }
}
