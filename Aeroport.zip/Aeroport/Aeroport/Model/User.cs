﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Model
{
    public class User
    {
        protected string utilizator;
        protected string parola;
        protected string tipUser;
        protected string id;
        public User(string utilizator, string parola, string tipUser, string id)
        {
            this.utilizator = utilizator;
            this.parola  = parola;
            this.tipUser = tipUser;
            this.id = id;
        }

        public string Utilizator
        {
            get { return utilizator; }
            set { utilizator = value; }
        }

        public string Parola
        {
            get { return parola; }
            set { parola = value; }
        }

        public string TipUser
        {
            get { return tipUser; }
            set { tipUser = value; }
        }

        public string Id
        {
            get { return id; }
            set { id = value; }
        }
        public override string ToString()
        {
            string s = "Utilizatorul: " + this.utilizator;
            s += " Parola: " + this.parola;
            s += " Tip user: " + this.tipUser;
            s += " Id: " + this.id;

            return s;
        }
    }
}
