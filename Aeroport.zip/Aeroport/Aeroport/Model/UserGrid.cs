﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Model
{
    public class UserGrid
    {
        public string id { get; set; }
        public string utilizator { get; set; }
        public string parola { get; set; }
        public string tipUser { get; set; }
    }
}
