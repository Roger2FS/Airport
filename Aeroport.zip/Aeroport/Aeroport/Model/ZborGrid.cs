﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Model
{
    public class ZborGrid
    {
        public string flyAeroport { get; set; }
        public string flyDestinatie { get; set; }
        public string flyNumarZbor { get; set; }
        public string flydurataZbor { get; set; }
        public string flyPretZbor { get; set; }
        public string flyDataPlecare { get; set; }
        public string flyDataRevenire { get; set; }
    }
}
