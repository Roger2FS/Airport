﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;

namespace Aeroport.Model.Repository
{
    public class ZborRepository
    {
        private Repository repository;  

        public ZborRepository()
        {
            this.repository = new Repository();
        }

        public bool aeroportExista(string aeroport)
        {
            using (SqlConnection con = new SqlConnection(@"Server=INTEL\SQLEXPRESS;DataBase=airport;Integrated Security=True"))
            {
                con.Open();
                string query = "SELECT COUNT(1) FROM zbor WHERE aeroport = @aeroport";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@aeroport", aeroport);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count > 0;
            }
        }

        public bool destinatieExista(string destinatie)
        {
            using (SqlConnection con = new SqlConnection(@"Server=INTEL\SQLEXPRESS;DataBase=airport;Integrated Security=True"))
            {
                con.Open();
                string query = "SELECT COUNT(1) FROM zbor WHERE destinatie = @destinatie";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@destinatie", destinatie);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count > 0;
            }
        }

        public bool AddFly(Zbor fly)
        {
            string commandSQL = "INSERT INTO zbor (aeroport, destinatie, pret, durata, numarZbor, modalitate, dataPlecare, dataRevenire, locuri) values ('";
            commandSQL += fly.Airport + "'";
            commandSQL += ", '" + fly.Destinatie + "'";
            commandSQL += ", '" + fly.Pret + "'";
            commandSQL += ", '" + fly.Durata + "'";
            commandSQL += ", '" + fly.NumarZbor + "'";
            commandSQL += ", '" + fly.Modalitate + "'";
            commandSQL += ", '" + fly.DataPlecare + "'";
            commandSQL += ", '" + fly.DataRevenire + "'";
            commandSQL += ", '" + fly.Locuri + "')";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool DeleteFly(int numarZbor)
        {
            string commandSQL = "delete from zbor where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateAeroport(int numarZbor, Zbor fly)
        {
            string commandSQL = "update zbor set aeroport = '";
            commandSQL += fly.Airport + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateDestinatie(string destinatie, string numarZbor)
        {
            string commandSQL = "update zbor set destinatie = '";
            commandSQL += destinatie + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }        
        public bool UpdateAeroport(string aeroport, string numarZbor)
        {
            string commandSQL = "update zbor set aeroport = '";
            commandSQL += aeroport + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }
        

        public bool UpdatePret(string pret, string numarZbor)
        {
            string commandSQL = "update zbor set pret = '";
            commandSQL += pret + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateAeroportDestinatiePret(string aeroport, string destinatie, string pret, string numarZbor)
        {
            string commandSQL = "update zbor set aeroport = '";
            commandSQL += aeroport + "' , destinatie = '";
            commandSQL += destinatie + "', pret = '";
            commandSQL += pret + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateDestinatieDurataPret(string destinatie, string durata, string pret, string numarZbor)
        {
            string commandSQL = "update zbor set destinatie = '";
            commandSQL += destinatie + "' , durata = '";
            commandSQL += durata + "', pret = '";
            commandSQL += pret + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }
        
        public bool UpdateAll(string aeroport, string destinatie, string pret, string durata, string numarZbor)
        {
            string commandSQL = "update zbor set aeroport = '";
            commandSQL += aeroport + "' , destinatie = '";
            commandSQL += destinatie + "', durata = '";
            commandSQL += durata + "', pret = '";
            commandSQL += pret + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateAeroportDestinatie(string aeroport, string destinatie, string numarZbor)
        {
            string commandSQL = "update zbor set aeroport = '";
            commandSQL += aeroport + "' , destinatie = '";
            commandSQL += destinatie + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateAeroportDurata(string aeroport, string durata, string numarZbor)
        {
            string commandSQL = "update zbor set aeroport = '";
            commandSQL += aeroport + "' , durata = '";
            commandSQL += durata + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }   
        
        public bool UpdateAeroportPret(string aeroport, string pret, string numarZbor)
        {
            string commandSQL = "update zbor set aeroport = '";
            commandSQL += aeroport + "' , pret = '";
            commandSQL += pret + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }      
        
        public bool UpdateDestinatiaDurata(string destinatia, string durata, string numarZbor)
        {
            string commandSQL = "update zbor set destinatie = '";
            commandSQL += destinatia + "' , durata = '";
            commandSQL += durata + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }        
        public bool UpdateDestinatiaPret(string destinatia, string pret, string numarZbor)
        {
            string commandSQL = "update zbor set destinatie = '";
            commandSQL += destinatia + "' , pret = '";
            commandSQL += pret + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }        
        
        public bool UpdateAeroportDestinatieDurata(string aeroport, string destinatie, string durata, string numarZbor)
        {
            string commandSQL = "update zbor set aeroport = '";
            commandSQL += aeroport + "' , destinatie = '";
            commandSQL += destinatie + "', durata = '";
            commandSQL += durata + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateDurata(string durata, string numarZbor)
        {
            string commandSQL = "update zbor set durata = '";
            commandSQL += durata + "' ";
            commandSQL += "where numarZbor = '" + numarZbor + "'";

            return this.repository.CommandSQL(commandSQL);
        }
        public DataTable FlyTable()
        {
            string selectSQL = "select * from zbor order by aeroport, destinatie";

            DataTable flyTable = this.repository.GetTable(selectSQL);
            if (flyTable == null || flyTable.Rows.Count == 0)
            {
                return null;
            }

            return flyTable;
        }

        public List<Zbor> FlyList()
        {
            DataTable flyTable = this.FlyTable();
            if (flyTable == null)
            {
                return null;
            }

            List<Zbor> list = new List<Zbor>();
            foreach (DataRow f in flyTable.Rows)
            {
                Zbor fly = this.convertToZbor(f);
                list.Add(fly);
            }

            return list;
        }

        public List<Zbor> FlyList_Department(int numarZbor)
        {
            string selectSQL = "Select * from zbor where numarZbor ='";
            selectSQL += numarZbor + "' order by Name";
            DataTable flyTable = this.repository.GetTable(selectSQL);

            if (flyTable == null || flyTable.Rows.Count == 0)
            {
                return null;
            }

            List<Zbor> list = new List<Zbor>();
            foreach (DataRow f in flyTable.Rows)
            {
                Zbor fly = this.convertToZbor(f);
                list.Add(fly);
            }

            return list;
        }

        public void updateValue(string aeroport, string destinatie)
        {
            string commandSQL = "update santinela set idZbor = (select id from zbor where aeroport = '" + aeroport + "' and destinatie = '" + destinatie + "')";
            this.repository.CommandSQL(commandSQL);
        }

        public void updateSantinela(string aeroport, string destinatie, string numarPasageri)
        {
            string commandSQL = "update santinela set aeroport = '" + aeroport + "', destinatie = '" + destinatie + "', numarBilete = '" + numarPasageri + "'";
            this.repository.CommandSQL(commandSQL);
        }
        public bool getSearchedFly(string aeroport, string destinatie, string dataPlecare, string dataIntoarcere, string numarPasageri)
        {
            try
            {
                string searchSQL = "select * from zbor where aeroport = '" + aeroport + "' and destinatie = '" + destinatie + "' and dataPlecare = '" + dataPlecare +
                    "' and dataRevenire = '" + dataIntoarcere + "'";

                DataTable flyTable = this.repository.GetTable(searchSQL);
                if (flyTable == null || flyTable.Rows.Count == 0)
                {
                    return false;
                }

                DataRow f = flyTable.Rows[0];
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public int numarPasageri(string aeroport, string destinatie)
        {
            string command = "select * from zbor";

            DataTable ticketTable = this.repository.GetTable(command);

            foreach (DataRow row in ticketTable.Rows)
            {
                if ((string)row["aeroport"] == aeroport && (string)row["destinatie"] == destinatie)
                {
                    return (int)row["locuri"];
                }
            }

            return -1; 
        }

        public void updateNrPasageri(string aeroport, string destinatie, int locuri)
        {
            string commandSQL = "update zbor set locuri = '" + locuri + "' where aeroport = '" + aeroport + "' and destinatie = '" + destinatie + "'";
            this.repository.CommandSQL(commandSQL);
        }

        public Zbor SearchFlyByNumarZbor(int numarZbor)
        {
            try
            {
                int numarFly = Convert.ToInt32(numarZbor);
                string searchSQL = "Select * from zbor where numarZbor = '" + numarZbor + "'" ;

                DataTable flyTable = this.repository.GetTable(searchSQL);
                if (flyTable == null || flyTable.Rows.Count == 0)
                {
                    return null;
                }

                DataRow f = flyTable.Rows[0];
                return this.convertToZbor(f);
            }
            catch (Exception)
            {
                return null;
            }
        }

        private Zbor convertToZbor(DataRow dataRow)
        {
            string aeroport = (string)dataRow["aeroport"];
            string destinatie = (string)dataRow["destinatie"];
            int numarZbor = (int)dataRow["numarZbor"];
            int pret = (int)dataRow["pret"];
            int durata = (int)dataRow["durata"];
            string modalitate = (string)dataRow["modalitate"];
            string dataPlecare = (string)dataRow["dataPlecare"];
            string dataRevenire = (string)dataRow["dataRevenire"];
            int locuri = (int)dataRow["locuri"];

            return new Zbor( (string)aeroport, (string)destinatie, (string)numarZbor.ToString(), (string)pret.ToString(), (string)durata.ToString(), (string)modalitate, (string)dataPlecare, (string)dataRevenire, (int)locuri); 
        }
    }
}
