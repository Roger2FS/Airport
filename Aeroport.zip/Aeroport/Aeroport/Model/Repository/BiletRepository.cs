﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Model.Repository
{
    public class BiletRepository
    {
        private Repository repository;
        public BiletRepository()
        {
            this.repository = new Repository();
        }

        public string getIdZbor()
        {
            string commandSQL = "select idZbor from aux";

            DataTable ticketTable = this.repository.GetTable(commandSQL);
            if (ticketTable == null || ticketTable.Rows.Count == 0)
            {
                return null;
            }

            DataRow ticketRow = ticketTable.Rows[0];
            string idZbor = (string)ticketRow["idZbor"];

            return idZbor;
        }

        public string getIdUser()
        {
            string commandSQL = "select idUser from aux";

            DataTable ticketTable = this.repository.GetTable(commandSQL);
            if (ticketTable == null || ticketTable.Rows.Count == 0)
            {
                return null;
            }

            DataRow ticketRow = ticketTable.Rows[0];
            string idUser = (string)ticketRow["idUser"];

            return idUser;
        }
        public bool AddBilet()
        {
            string command = "select * from santinela";

            DataTable ticketTable = this.repository.GetTable(command);

            DataRow ticketRow = ticketTable.Rows[0];
            int idUtilizator = (int)ticketRow["tipUtilizator"];
            string aeroport = (string)ticketRow["aeroport"];
            string destinatie = (string)ticketRow["destinatie"];
            int nr = (int)ticketRow["numarBilete"];

            int idUser = (int)ticketRow["idUser"];
            int idZbor = (int)ticketRow["idZbor"];

            string command2 = "select * from bilet";

            DataTable ticketTable2 = this.repository.GetTable(command2);
            int bilete = 0; 

            foreach (DataRow row in ticketTable.Rows)
            {
                if ((int)row["idZbor"] == idZbor && (int)row["idUser"] == idUser)
                {
                    bilete = (int)row["numarBilete"];
                }
            }

            int numtotal = bilete + nr; 

            string commandSQL2 = "select * from zbor where aeroport = '" + aeroport + "', destinatie = '" + destinatie + "'"; 
            this.repository.CommandSQL(commandSQL2);

            if (idUtilizator == 0) {
                return false;
            }
            else
            {
                string commandSQL = "insert into bilet (idZbor,idUser,numarBilete) values ((select idZbor from santinela),(select idUser from santinela), '" + numtotal + "')";

                return this.repository.CommandSQL(commandSQL);
            }

            return false;
        }

        public bool DeleteTicket(int id)
        {
            string commandSQL = "delete from bilet where id = '" + id + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public DataTable TicketTable()
        {
            string selectSQL = "select * from bilet";

            DataTable ticketTable = this.repository.GetTable(selectSQL);
            if (ticketTable == null || ticketTable.Rows.Count == 0)
            {
                return null;
            }

            return ticketTable;
        }

        public List<Bilet> FlyList()
        {
            DataTable ticketTable = this.TicketTable();
            if (ticketTable == null)
            {
                return null;
            }

            List<Bilet> list = new List<Bilet>();
            foreach (DataRow f in ticketTable.Rows)
            {
                Bilet ticket = this.convertToBilet(f);
                list.Add(ticket);
            }

            return list;
        }

        public List<Bilet> TicketList_Id(int id)
        {
            string selectSQL = "select * from bilet where id ='";
            selectSQL += id + "'";
            DataTable ticketTable = this.repository.GetTable(selectSQL);

            if (ticketTable == null || ticketTable.Rows.Count == 0)
            {
                return null;
            }

            List<Bilet> list = new List<Bilet>();
            foreach (DataRow f in ticketTable.Rows)
            {
                Bilet ticket = this.convertToBilet(f);
                list.Add(ticket);
            }

            return list;
        }

        public Bilet SearchBiletById(int id)
        {
            try
            {
                int ID = Convert.ToInt32(id);
                string searchSQL = "select * from bilet where id = '" + id + "'";

                DataTable ticketTable = this.repository.GetTable(searchSQL);
                if (ticketTable == null || ticketTable.Rows.Count == 0)
                {
                    return null;
                }

                DataRow f = ticketTable.Rows[0];
                return this.convertToBilet(f);
            }
            catch (Exception)
            {
                return null;
            }
        }

        private Bilet convertToBilet(DataRow dataRow)
        {
            int idZbor = (int)dataRow["idZbor"];
            int idUser = (int)dataRow["idUser"];
            int id = (int)dataRow["id"];
            int numarBilete = (int)dataRow["numarBilete"];

            return new Bilet((string)id.ToString(),(string)idZbor.ToString(), (string)idUser.ToString(), (string)numarBilete.ToString());
        }
    }
}
