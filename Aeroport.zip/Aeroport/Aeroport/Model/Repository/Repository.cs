﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Aeroport.Model.Repository
{
    public class Repository
    {
        protected SqlConnection connection;

        public Repository()
        {
            this.connection = new SqlConnection(@"Server = INTEL\SQLEXPRESS; DataBase = airport; Integrated Security = True");
        }

        public SqlConnection Connection
        {
            get { return this.connection; }
            set { this.connection = value; }
        }

        public void OpeningConnection()
        {
            this.connection.Open();
        }

        public void ClosingConnection()
        {
            this.connection.Close();
        }

        public bool CommandSQL(string commandSQL)
        {
            bool result = true;
            try
            {
                this.OpeningConnection();
                SqlCommand command = new SqlCommand(commandSQL, this.connection);
                if (command.ExecuteNonQuery() == 0)
                    result = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                result = false;
            }
            finally
            {
                this.ClosingConnection();
            }

            return result;
        }

        public DataTable GetTable(string commandSQL)
        {
            DataTable result = null;
            try
            {
                this.OpeningConnection();
                SqlCommand command = new SqlCommand(commandSQL, this.connection);
                SqlDataAdapter readData = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                readData.Fill(table);
                result = table;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                this.ClosingConnection();
            }
            return result;
        }
    }
}
