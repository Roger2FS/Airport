﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Model.Repository
{
    public class UserRepository
    {
        private Repository repository;

        public UserRepository()
        {
            this.repository = new Repository();
        }

        public bool addUser(string utilizator, string parola, string tipUser)
        {
            string commandSQL = "INSERT INTO utilizator (utilizator, parola, tipUser) values ('";
            commandSQL += utilizator + "'";
            commandSQL += ", '" + parola + "'";
            commandSQL += ", '" + tipUser + "')";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool AddUser(User u)
        {
            string commandSQL = "INSERT INTO utilizator (utilizator, parola, tipUser) values ('";
            commandSQL += u.Utilizator + "'";
            commandSQL += ", '" + u.Parola + "'";
            commandSQL += ", '" + u.TipUser + "')";

            return this.repository.CommandSQL(commandSQL);
        }
        public bool DeleteUser(string id)
        {
            string commandSQL = "delete from utilizator where id = '" + id + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateUtilizator(string id, string utilizator)
        {
            string commandSQL = "update utilizator set utilizator = '";
            commandSQL += utilizator + "' ";
            commandSQL += "where id = '" + id + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateParola(string id, string parola)
        {
            string commandSQL = "update utilizator set parola = '";
            commandSQL += parola + "' ";
            commandSQL += "where id = '" + id + "'";

            return this.repository.CommandSQL(commandSQL);
        }
        public bool UtilizatorExista(string utilizator)
        {
            using (SqlConnection con = new SqlConnection(@"Server=INTEL\SQLEXPRESS;DataBase=airport;Integrated Security=True"))
            {
                con.Open();
                string query = "SELECT COUNT(1) FROM utilizator WHERE utilizator = '" + utilizator + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@utilizator", utilizator);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count > 0;
            }
        }

        public bool ParolaExista(string parola)
        {
            using (SqlConnection con = new SqlConnection(@"Server=INTEL\SQLEXPRESS;DataBase=airport;Integrated Security=True"))
            {
                con.Open();
                string query = "SELECT COUNT(1) FROM utilizator WHERE parola = '" + parola + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@utilizator", parola);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count > 0;
            }
        }
        public bool updateParola(string utilizator, string parola)
        {
            string commandSQL = "update utilizator set parola = '";
            commandSQL += parola + "' ";
            commandSQL += "where utilizator = '" + utilizator + "'";

            return this.repository.CommandSQL(commandSQL);
        }
        public bool UpdateTipUser(string id, string tipUser)
        {
            string commandSQL = "update utilizator set tipUser = '";
            commandSQL += tipUser + "' ";
            commandSQL += "where id = '" + id + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateAll(string utilizator, string parola, string tipUser, string id)
        {
            string commandSQL = "update utilizator set utilizator = '";
            commandSQL += utilizator + "' , parola = '";
            commandSQL += parola + "', tipUser = '";
            commandSQL += tipUser + "' ";
            commandSQL += "where id = '" + id + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateUtilizatorParola(string utilizator, string parola, string id)
        {
            string commandSQL = "update utilizator set utilizator = '";
            commandSQL += utilizator + "' , parola = '";
            commandSQL += parola + "' ";
            commandSQL += "where id = '" + id + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateUtilizatorTipUser(string utilizator, string tipUser, string id)
        {
            string commandSQL = "update utilizator set utilizator = '";
            commandSQL += utilizator + "' , tipUser = '";
            commandSQL += tipUser + "' ";
            commandSQL += "where id = '" + id + "'";

            return this.repository.CommandSQL(commandSQL);
        }

        public bool UpdateParolaTipUser(string parola, string tipUser, string id)
        {
            string commandSQL = "update utilizator set parola = '";
            commandSQL += parola + "' , tipUser = '";
            commandSQL += tipUser + "' ";
            commandSQL += "where id = '" + id + "'";

            return this.repository.CommandSQL(commandSQL);
        }
        public DataTable UsersTable()
        {
            string selectSQL = "select * from utilizator";

            DataTable flyTable = this.repository.GetTable(selectSQL);
            if (flyTable == null || flyTable.Rows.Count == 0)
            {
                return null;
            }

            return flyTable;
        }

        public List<User> UsersList()
        {
            DataTable usersTable = this.UsersTable();
            if (usersTable == null)
            {
                return null;
            }

            List<User> list = new List<User>();
            foreach (DataRow f in usersTable.Rows)
            {
                User u = this.convertToUser(f);
                list.Add(u);
            }

            return list;
        }

        public List<User> UserList_Id(int id)
        {
            string selectSQL = "Select * from utilizator where id ='";
            selectSQL += id + "'";
            DataTable usersTable = this.repository.GetTable(selectSQL);

            if (usersTable == null || usersTable.Rows.Count == 0)
            {
                return null;
            }

            List<User> list = new List<User>();
            foreach (DataRow f in usersTable.Rows)
            {
                User userr = this.convertToUser(f);
                list.Add(userr);
            }

            return list;
        }

        public User SearchUserById(int id)
        {
            try
            {
                int ID = Convert.ToInt32(id);
                string searchSQL = "Select * from utilizator where id = '" + id + "'";

                DataTable userTable = this.repository.GetTable(searchSQL);
                if (userTable == null || userTable.Rows.Count == 0)
                {
                    return null;
                }

                DataRow f = userTable.Rows[0];
                return this.convertToUser(f);
            }
            catch (Exception)
            {
                return null;
            }
        }

        private User convertToUser(DataRow dataRow)
        {
            string utilizator = (string)dataRow["utilizator"];
            string parola = (string)dataRow["parola"];
            string tipUser = (string)dataRow["tipUser"];
            int id = (int)dataRow["id"];

            return new User((string) utilizator, (string) parola, (string) tipUser, (string) id.ToString());
        }

        public string getTipUtilizator(string utilizator, string parola)
        {
            string command = "select * from utilizator";

            DataTable usersTable = this.repository.GetTable(command);

            foreach (DataRow row in usersTable.Rows)
            {
                if ((string)row["utilizator"] == utilizator && (string)row["parola"] == parola)
                {
                    return (string)row["tipUser"];
                }
            }

            return "";
        }
        
        public bool updateSantinela()
        {
            string commandSQL = "update santinela set tipUtilizator = 0";

            return this.repository.CommandSQL(commandSQL);
        }
        public bool updateSantinela2()
        {
            string commandSQL = "update santinela set tipUtilizator = 1";

            return this.repository.CommandSQL(commandSQL);
        }
    }
}
