﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Model
{
    public class BiletGrid
    {
        public string id { get; set; }
        public string idUser { get; set; }
        public string idZbor { get; set; }
        public string numarBilete { get; set; }
    }
}
