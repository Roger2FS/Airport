﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Model
{
    public class Bilet
    {
        public string id;
        protected string idZbor;
        protected string idUser;
        protected string numarBilete;
        public Bilet(string id, string idZbor, string idUser, string numarBilete)
        {
            this.id = id;
            this.idZbor = idZbor;
            this.idUser = idUser;
            this.numarBilete = numarBilete;
        }
        public string ID
        {
            get { return id; }
            set { id = value; }
        }
        public string IdZbor
        {
            get { return idZbor; }
            set { idZbor = value; }
        }

        public string IdUser
        {
            get { return idUser; }
            set { idUser = value; }
        }
        public string NumarBilete
        {
            get { return numarBilete; }
            set { numarBilete = value; }
        }
        public override string ToString()
        {
            string s = "ID: " + this.ID;
            s += " ID zbor: " + this.IdZbor;
            s += " ID user: " + this.IdUser;
            s += " Numar Bilete: " + this.NumarBilete;

            return s;
        }
    }
}
