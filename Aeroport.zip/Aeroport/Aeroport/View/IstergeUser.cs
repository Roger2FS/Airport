﻿using Aeroport.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Aeroport.View
{
    public interface IstergeUser
    {
        string getID();

        void mesajEsec();

        void mesajExceptie(string ex);

        void mesajIdInvalid();
        void mesajListaGoala();

        void mesajParolaInvalida();

        void mesajStergereEsec();

        void mesajStergereSucces();

        void mesajSucces();

        void mesajSuccesModificare();

        void mesajTipUserInvalida();

        void mesajUtilizatorInvalid();
    }
}
