﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows;

namespace Aeroport.View
{
    public interface IListaUser
    {
       DataGrid getGrid();
       void mesajAeroportInvalid();

       void mesajDestinatieInvalida();

       void mesajNrPasageriInvalid();

       void mesajDataPlecareInvalida();

       void mesajDataRevenireInvalida();

       void mesajEsec();

       void mesajExceptie(string ex);

       void mesajIdInvalid();

       void mesajListaGoala();

       void mesajParolaInvalida();

       void mesajStergereEsec();

       void mesajStergereSucces();

       void mesajSucces();

       void mesajSuccesModificare();

       void mesajTipUserInvalida();

       void mesajUtilizatorInvalid();
    }
}
