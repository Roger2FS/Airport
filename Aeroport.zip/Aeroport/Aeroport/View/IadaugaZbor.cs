﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Aeroport.View
{
    public interface IadaugaZbor
    {
        string GetPret();
        string GetNumarZbor();
        string GetDurataZbor();
        string GetModalitate();
        string GetNumarPasageri();
        void SetNumarZbor(string numarZbor);
        void SetPret(string pret);
        void SetDurataZbor(string durataZbor);
        void SetAeroport(string aeroport);
        void setDestinatie(string destinatie);
        void SetModalitate(string modalitate);
        void setDataPlecare(string value);
        void setDataRevenire(string value);
        void setNumarPasageri(string pasageri);
        void mesajDateInvalide();
        void mesajDurataInvalida();
        void mesajModalitateInvalida();
        void mesajNrZborInvalid();
        void mesajPretInvalid();
        void mesajSucces();
        void mesajEsec();
        void mesajStergereSucces();
        void mesajStergereEsec();
        void mesajSuccesModificare();
        void mesajEsecModificare();
        DataGrid getGrid();
    }
}
