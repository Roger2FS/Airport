﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Aeroport.View
{
    public interface IRegister
    {
        string getUtilizator();

        void setUtilizator(string utilizator);

        string getParola();

        void setParola(string parola);

        void mesajSucces();

        void mesajEsec();

        void mesajUtilizatorExista();
    }
}