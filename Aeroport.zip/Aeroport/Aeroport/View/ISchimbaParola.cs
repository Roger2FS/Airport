﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.View
{
    public interface ISchimbaParola
    {
        string getParola();
        string getUtilizator();
        void Succes();
        void Esec();
        void setParola(string parola);
        void setUtilizator(string utilizator);
        void mesajNuExistaUtilizator();

    }
}
