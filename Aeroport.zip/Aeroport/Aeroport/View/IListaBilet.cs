﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Aeroport.View
{
    public interface IListaBilet
    {
        void mesajListaGoala();
        void mesajExceptie(string ex);
        DataGrid getGrid();
    }
}
