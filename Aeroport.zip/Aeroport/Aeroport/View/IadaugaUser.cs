﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Aeroport.View
{
    public interface IadaugaUser
    {
        string getUtilizator();
        void setUtilizator(string utilizator);
        string getParola();
        void setParola(string parola);
        string getTipUtilizator();
        void setTipUtilizator(string tipUtilizator);
        string getID();
        void SetId(int id);
        void mesajSucces(); 
        void mesajEsec();
        void mesajExceptie(string ex);
        void mesajSuccesModificare(); 
        void mesajIdInvalid(); 
        void mesajUtilizatorInvalid(); 
        void mesajTipUserInvalida(); 
        void mesajParolaInvalida(); 
        void mesajListaGoala(); 
        void mesajStergereEsec(); 
        void mesajStergereSucces();
        DataGrid getGrid();

    }
}
