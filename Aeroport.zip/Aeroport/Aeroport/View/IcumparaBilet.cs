﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Aeroport.View
{
    public interface IcumparaBilet
    {
        void mesajSucces();
        void mesajEsec();
        void mesajExceptie(string ex);
        void mesajIDZborInvalid();
        void mesajIDUserInvalid();
        void mesajListaGoala();
        string getID();
        string getIdZbor();
        string getIdUser();
        DataGrid getGrid();
    }
}
