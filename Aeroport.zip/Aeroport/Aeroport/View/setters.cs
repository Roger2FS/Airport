﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.View
{
    public interface setters
    {
            void setDestinatie(string destinatie);
            void SetAeroport(string aeroport);
            void setDataPlecare(string dataPlecare);
            void setDataRevenire(string dataRevenire);
            void setNumarPasageri(string nrPasageri);
    }
}
