﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.View
{
    public interface IstergeZbor
    {
        string GetNumarZbor();
        void mesajStergereSucces();
        void mesajStergereEsec();
        void mesajExceptie(string ex);
        void SetNumarZbor(string numarZbor);
        void mesajNrZborInvalid();
    }
}
