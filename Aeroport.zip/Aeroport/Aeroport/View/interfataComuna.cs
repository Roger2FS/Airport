﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.View
{
    public interface interfataComuna
    {
        string GetFrom();
        string GetTo();
        string GetDataPlecare();
        string GetDataIntoarcere();
        string GetNumarPasageri();
        void mesajAeroportInvalid();
        void mesajDestinatieInvalida();
        void mesajNrPasageriInvalid();
        void mesajDataPlecareInvalida();
        void mesajDataRevenireInvalida();
        void mesajExceptie(string ex);
        void mesajListaGoala();
        void mesajGasireSucces();
        void mesajGasireEsec();
    }
}
