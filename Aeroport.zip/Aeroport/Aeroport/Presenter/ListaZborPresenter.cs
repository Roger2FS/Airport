﻿using Aeroport.Model;
using Aeroport.Model.Repository;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Aeroport.Presenter
{
    public class ListaZborPresenter<I1>
        where I1 : IListaZbor
    {
        private I1 z1;
        private ZborRepository flyRepository;
        public ListaZborPresenter(I1 z1)
        {
            this.z1 = z1;
            this.flyRepository = new ZborRepository();
        }

        public List<Zbor> allFlyies()
        {
            try
            {
                List<Zbor> list = this.flyRepository.FlyList();

                if (list == null)
                {
                    this.z1.mesajListaGoala();
                    return null;
                }
                else
                {
                    return list;
                }
            }
            catch (Exception e)
            {
                this.z1.mesajExceptie(e.ToString());
                return null;
            }
        }

        public void afisareLista()
        {
            List<Zbor> zbors = new List<Zbor>();
            zbors = this.allFlyies();

            int counter = zbors.Count;
            int i = 0;
            while (counter > 0)
            {
                DataGrid dg = this.z1.getGrid();
                ZborGrid flyes = new ZborGrid();
                Zbor row = zbors[i];

                flyes.flyAeroport = row.Airport;
                flyes.flyDestinatie = row.Destinatie;
                flyes.flydurataZbor = row.Durata;
                flyes.flyNumarZbor = row.NumarZbor;
                flyes.flyPretZbor = row.Pret;
                flyes.flyDataPlecare = row.DataPlecare;
                flyes.flyDataRevenire = row.DataRevenire;

                dg.Items.Add(flyes);
                counter--; i++;
            }
        }
    }
}
