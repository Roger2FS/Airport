﻿using Aeroport.Model;
using Aeroport.Model.Repository;
using Aeroport.View;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Aeroport.Presenter
{
    public class ZborPresenter<I1, I2>
        where I1 : IadaugaZbor
        where I2 : interfataComuna
    {
        private I1 adaugafly;
        private I2 adaugafly2;
        private ZborRepository flyRepository;
        public ZborPresenter(I1 adaugafly, I2 adaugafly2)
        {
            this.adaugafly = adaugafly;
            this.adaugafly2 = adaugafly2;
            this.flyRepository = new ZborRepository();
        }
        public void AddFly()
        {
            try
            {
                Zbor fly = this.validInformation();
                if (!this.aeroportExista(adaugafly2.GetFrom()) && !this.destinatieExista(adaugafly2.GetTo()) && this.VerificareDataPlecareRevenire(adaugafly2.GetDataPlecare(), adaugafly2.GetDataIntoarcere())) 
                {
                    if (fly != null)
                    {
                        bool result = this.flyRepository.AddFly(fly);
                        if (result)
                        {
                            this.adaugafly.mesajSucces();
                            this.resetFlyControls();
                        }
                        else
                        {
                            this.adaugafly.mesajEsec();
                            this.resetFlyControls();
                        }
                    }
                }
                else
                {
                    this.resetFlyControls();
                }
            }
            catch (Exception ex)
            {
                this.adaugafly.mesajEsec();
            }
        }

        public bool aeroportExista(string aeroport)
        {
            return this.flyRepository.aeroportExista(aeroport);
        }

        public bool destinatieExista(string destinatie)
        {
            return this.flyRepository.destinatieExista(destinatie);
        }

        public bool VerificareDataPlecareRevenire(string dataPlecare, string dataRevenire)
        {
            if (!DateTime.TryParse(dataPlecare, out DateTime plecare) || !DateTime.TryParse(dataRevenire, out DateTime revenire))
            {
                return false;
            }

            if (plecare >= revenire)
            {
                return false;
            }

            if (plecare.Month > 12 || revenire.Month > 12 || plecare.Day < 1 || revenire.Day < 1 ||
                plecare.Day > DateTime.DaysInMonth(plecare.Year, plecare.Month) || revenire.Day > DateTime.DaysInMonth(revenire.Year, revenire.Month))
            {
                return false;
            }

            return true;
        }

        public void deleteFly()
        {
            try
            {
                string numarZbor = this.getNumarZbor();
                int nrZbor = int.Parse(numarZbor);

                bool z = this.flyRepository.DeleteFly(nrZbor);

                if (z)
                {
                    this.adaugafly.mesajStergereSucces();
                    this.res();
                }
                else
                {
                    this.adaugafly.mesajStergereEsec();
                    this.res();
                }
            }
            catch (Exception ex)
            {
                this.adaugafly2.mesajExceptie(ex.ToString());
            }
        }
        public void UpdateFly()
        {
            string aeroport = adaugafly2.GetFrom();
            string destinatie = adaugafly2.GetTo();
            string pretZbor = adaugafly.GetPret();
            string durataZbor = adaugafly.GetDurataZbor();
            string numarZbor = adaugafly.GetNumarZbor();
            int pret = 0;
            int durata = 0;
            int numar = 0;

            if (!pretZbor.Equals(""))
            {
                pret = int.Parse(pretZbor);
            }
            if (!durataZbor.Equals(""))
            {
                durata = int.Parse(durataZbor);
            }
            if (!numarZbor.Equals(""))
            {
                numar = int.Parse(numarZbor);
            }

            try
            {
                // schimbam aeroport
                if (!aeroport.Equals("") && destinatie.Equals("") && durata.Equals("") && pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateAeroport(aeroport, numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam destinatia 
                if (aeroport.Equals("") && !destinatie.Equals("") && durata == -1 && pret == -1)
                {
                    bool result = this.flyRepository.UpdateDestinatie(destinatie,numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam durata zborului
                if (aeroport.Equals("") && destinatie.Equals("") && !durata.Equals("") && pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateDurata(durata.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam pretul zborului
                if (aeroport.Equals("") && destinatie.Equals("") && durata.Equals("") && !pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdatePret(pret.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam aeroportul, destinatia
                if (!aeroport.Equals("") && !destinatie.Equals("") && durata.Equals("") && pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateAeroportDestinatie(aeroport, destinatie, numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam aeroportul, durata zborului
                if (!aeroport.Equals("") && destinatie.Equals("") && !durata.Equals("") && pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateAeroportDurata(aeroport, durata.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam aeroportul, pretul zborului
                if (!aeroport.Equals("") && destinatie.Equals("") && durata.Equals("") && !pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateAeroportPret(aeroport, pret.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schibam destinatia, durata zborului
                if (aeroport.Equals("") && !destinatie.Equals("") && !durata.Equals("") && pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateDestinatiaDurata(destinatie, durata.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam destinatia, pretul zborului
                if (aeroport.Equals("") && !destinatie.Equals("") && durata == -1 && pret != -1)
                {
                    bool result = this.flyRepository.UpdateDestinatiaPret(destinatie, pret.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam durata, pretul zborului
                if (!aeroport.Equals("") && !destinatie.Equals("") && durata.Equals("") && pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateAeroportDestinatie(aeroport, destinatie, numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam aeroportul, destinatia, durata zborului
                if (!aeroport.Equals("") && !destinatie.Equals("") && !durata.Equals("") && pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateAeroportDestinatieDurata(aeroport, destinatie, durata.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam aeroportul, destinatia, pretul zborului
                if (!aeroport.Equals("") && !destinatie.Equals("") && durata.Equals("") && !pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateAeroportDestinatiePret(aeroport, destinatie, pret.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                //schimbam destinatia, durata, pretul zborului
                if (aeroport.Equals("") && !destinatie.Equals("") && !durata.Equals("") && !pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateDestinatieDurataPret(destinatie, durata.ToString(), pret.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }

                // schimbam tot
                if (!aeroport.Equals("") && !destinatie.Equals("") && !durata.Equals("") && !pret.Equals(""))
                {
                    bool result = this.flyRepository.UpdateAll(aeroport, destinatie, durata.ToString(), pret.ToString(), numarZbor);
                    this.adaugafly.mesajSuccesModificare();
                    this.reset();
                    return;
                }
            }
            catch (Exception exception)
            {
                this.adaugafly2.mesajExceptie(exception.ToString());
            }
        }
        private string getNumarZbor()
        {
            string nrZbor = adaugafly.GetNumarZbor();
            int numarZbor = int.Parse(nrZbor);

            if (numarZbor < 0) {
                this.adaugafly.mesajNrZborInvalid();
                return "";
            }

            return nrZbor;
        }
        private Zbor validInformation()
        {
            string sursa = adaugafly2.GetFrom();
            string destinatie = adaugafly2.GetTo();
            string nrZbor = adaugafly.GetNumarZbor();
            string pret = adaugafly.GetPret();
            string durata = adaugafly.GetDurataZbor();
            string modalitate = adaugafly.GetModalitate();
            string dataPlecare = adaugafly2.GetDataPlecare();
            string dataRevenire = adaugafly2.GetDataIntoarcere();
            string locuri = adaugafly2.GetNumarPasageri();

            int nrLocuri = int.Parse(locuri);

            if (sursa == null || sursa.Length == 0)
            {
                this.adaugafly2.mesajAeroportInvalid();
                return null;
            }

            if (destinatie == null || destinatie.Length == 0)
            {
                this.adaugafly2.mesajDestinatieInvalida();
                return null;
            }

            if (nrZbor == null || nrZbor.Length == 0)
            {
                this.adaugafly.mesajNrZborInvalid();
                return null;
            }

            if (pret == null || pret.Length == 0)
            {
                this.adaugafly.mesajPretInvalid();
                return null;
            }

            if (durata == null || durata.Length == 0)
            {
                this.adaugafly.mesajDurataInvalida();
                return null;
            }

            if (modalitate.Equals("Dus") || modalitate.Equals("Dus-Intors"))
            {

            }
            else
            {
                this.adaugafly.mesajModalitateInvalida();
                return null;
            }

            if (dataPlecare == null || dataPlecare.Length == 0)
            {
                this.adaugafly2.mesajDataPlecareInvalida();
                return null;
            }

            if (dataRevenire == null || dataRevenire.Length == 0)
            {
                this.adaugafly2.mesajDataRevenireInvalida();
                return null;
            }

            if (nrLocuri < 0)
            {
                this.adaugafly2.mesajNrPasageriInvalid();
                return null;
            }

            return new Zbor(sursa, destinatie, nrZbor, pret, durata, modalitate, dataPlecare, dataRevenire, nrLocuri);
        }
        public List<Zbor> allFlyies()
        {
            try
            {
                List<Zbor> list = this.flyRepository.FlyList();

                if (list == null)
                {
                    this.adaugafly2.mesajListaGoala();
                    return null;
                }
                else
                {
                    return list;
                }
            }
            catch (Exception e)
            {
                this.adaugafly2.mesajExceptie(e.ToString());
                return null;
            }
        }

        public void afisareLista()
        {
            List<Zbor> zbors = new List<Zbor>();
            zbors = this.allFlyies();

            int counter = zbors.Count;
            int i = 0;
            while (counter > 0)
            {
                DataGrid dg = this.adaugafly.getGrid();
                ZborGrid flyes = new ZborGrid();
                Zbor row = zbors[i];

                flyes.flyAeroport = row.Airport;
                flyes.flyDestinatie = row.Destinatie;
                flyes.flydurataZbor = row.Durata;
                flyes.flyNumarZbor = row.NumarZbor;
                flyes.flyPretZbor = row.Pret;
                flyes.flyDataPlecare = row.DataPlecare;
                flyes.flyDataRevenire = row.DataRevenire;

                dg.Items.Add(flyes);
                counter--; i++;
            }
        }

        private void res()
        {
            this.adaugafly.SetNumarZbor("");
        }
        private void reset()
        {
            this.adaugafly.setDestinatie("");
            this.adaugafly.SetAeroport("");
            this.adaugafly.SetPret("");
            this.adaugafly.SetNumarZbor("");
            this.adaugafly.SetDurataZbor("");
        }
        private void resetFlyControls()
        {
            this.adaugafly.setDestinatie("");
            this.adaugafly.SetAeroport("");
            this.adaugafly.SetModalitate("");
            this.adaugafly.SetPret("");
            this.adaugafly.SetNumarZbor("");
            this.adaugafly.setDataPlecare("");
            this.adaugafly.setDataRevenire("");
            this.adaugafly.setNumarPasageri("");
            this.adaugafly.SetDurataZbor("");
        }
    }
}
