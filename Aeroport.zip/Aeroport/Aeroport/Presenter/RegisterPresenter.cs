﻿using Aeroport.Model.Repository;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Presenter
{
    public class RegisterPresenter
    {
        private IRegister register;
        private UserRepository userRep;
        public RegisterPresenter(IRegister register)
        {
            this.register = register;
            this.userRep = new UserRepository();
        }

        public void creareCont()
        {
            bool uExista = this.userRep.UtilizatorExista(this.register.getUtilizator());
            bool pExista = this.userRep.ParolaExista(this.register.getParola());

            if(!uExista && !pExista)
            {
                bool add = this.userRep.addUser(this.register.getUtilizator(), this.register.getParola(), "Calator");

                if(add)
                {
                    this.register.mesajSucces();
                    this.register.setUtilizator("");
                    this.register.setUtilizator("");
                    MainWindow main = new MainWindow();
                    main.Show();
                }
                else
                {
                    this.register.mesajEsec();
                    this.register.setUtilizator("");
                    this.register.setUtilizator("");
                }
            }
            else
            {
                this.register.mesajUtilizatorExista();
                this.register.setUtilizator("");
                this.register.setUtilizator("");
            }

        }
    }
}
