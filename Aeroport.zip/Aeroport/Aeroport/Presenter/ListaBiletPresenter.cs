﻿using Aeroport.Model;
using Aeroport.Model.Repository;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Aeroport.Presenter
{
    public class ListaBiletPresenter
    {
        private IListaBilet listaBiletee;
        private BiletRepository ticketRepository;
        public ListaBiletPresenter(IListaBilet listaBiletee)
        {
            this.listaBiletee = listaBiletee;
            this.ticketRepository = new BiletRepository();
        }
        public List<Bilet> allTickets()
        {
            try
            {
                List<Bilet> list = this.ticketRepository.FlyList();

                if (list == null)
                {
                    this.listaBiletee.mesajListaGoala();
                    return null;
                }
                else
                {
                    return list;
                }
            }
            catch (Exception e)
            {
                this.listaBiletee.mesajExceptie(e.ToString());
                return null;
            }
        }

        public void afisareLista()
        {
            List<Bilet> bilete = new List<Bilet>();
            bilete = this.allTickets();

            int counter = bilete.Count;
            int i = 0;
            while (counter > 0)
            {
                DataGrid dt = this.listaBiletee.getGrid();
                BiletGrid tickets = new BiletGrid();
                Bilet row = bilete[i];

                tickets.id = row.id;
                tickets.idZbor = row.IdZbor;
                tickets.idUser = row.IdUser;
                tickets.numarBilete = row.NumarBilete;

                dt.Items.Add(tickets);
                counter--; i++;
            }
        }
    }
}
