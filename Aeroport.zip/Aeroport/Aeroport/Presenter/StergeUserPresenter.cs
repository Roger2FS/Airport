﻿using Aeroport.Model.Repository;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Presenter
{
    public class StergeUserPresenter
    {
        private IstergeUser stergeUser;
        private UserRepository userRepository;
        public StergeUserPresenter(IstergeUser stergeUser)
        {
            this.stergeUser = stergeUser;
            this.userRepository = new UserRepository();
        }
        public void deleteUser()
        {
            try
            {
                string id = this.getID();
                bool z = this.userRepository.DeleteUser(id);

                if (z)
                {
                    this.stergeUser.mesajStergereSucces();
                }
                else
                {
                    this.stergeUser.mesajStergereEsec();
                }
            }
            catch (Exception ex)
            {
                this.stergeUser.mesajExceptie(ex.ToString());
            }
        }

        private string getID()
        {
            string id = stergeUser.getID();

            return id;
        }
    }
}
