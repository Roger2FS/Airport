﻿using Aeroport.Model.Repository;
using Aeroport.Model;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using System.Security.Cryptography;

namespace Aeroport.Presenter
{
    public class SearchFlyPresenter
    {
        private interfataComuna searchFly;
        private setters set;
        private ZborRepository flyRepository;
        public SearchFlyPresenter(interfataComuna iFly, setters set)
        {
            this.searchFly = iFly;
            this.flyRepository = new ZborRepository();
            this.set = set;
        }
        public void getSearchedZbor()
        {
            string aeroport = searchFly.GetFrom();
            string destinatie = searchFly.GetTo();
            string dataPlecare = searchFly.GetDataPlecare();
            string dataRevenire = searchFly.GetDataIntoarcere();
            string numarPasageri = searchFly.GetNumarPasageri();
            int nrPasageri = int.Parse(numarPasageri);

            this.flyRepository.updateSantinela(aeroport, destinatie, numarPasageri);
            int nrPasageriBazaDate = this.flyRepository.numarPasageri(aeroport, destinatie);

            bool check = true;

            if (aeroport == null || aeroport.Length == 0)
            {
                this.searchFly.mesajAeroportInvalid();
                check = false;
            }

            if (destinatie == null || destinatie.Length == 0)
            {
                this.searchFly.mesajDestinatieInvalida();
                check = false;
            }

            if (dataPlecare == null || dataPlecare.Length == 0)
            {
                this.searchFly.mesajDataPlecareInvalida();
                check = false;
            }

            if (dataRevenire == null || dataRevenire.Length == 0)
            {
                this.searchFly.mesajDataRevenireInvalida();
                check = false;
            }

            if (nrPasageri < 0 || nrPasageriBazaDate - nrPasageri < 0)
            {
                this.searchFly.mesajNrPasageriInvalid();
                check = false;
            }

            this.flyRepository.updateNrPasageri(aeroport, destinatie, nrPasageriBazaDate - nrPasageri);

            DateTime dataObiect1 = DateTime.ParseExact(dataPlecare, "dd.MM.yyyy", null);
            string dataNouaPlecare = dataObiect1.ToString("dd-MM-yyyy");

            DateTime dataObiect2 = DateTime.ParseExact(dataRevenire, "dd.MM.yyyy", null);
            string dataNouaRevenire = dataObiect2.ToString("dd-MM-yyyy");

            if (check)
            {
                bool b = this.flyRepository.getSearchedFly(aeroport, destinatie, dataNouaPlecare, dataNouaRevenire, numarPasageri);

                if (b)
                {
                    this.searchFly.mesajGasireSucces();
                    this.flyRepository.updateValue(aeroport,destinatie);
                    CumparaBilet cump = new CumparaBilet();
                    cump.Show();
                    this.reset();
                }
                else
                {
                    this.searchFly.mesajGasireEsec();
                }
            }
            else
            {
                this.searchFly.mesajExceptie("Eroare!");
            }
        }
        public List<Zbor> allFlyies()
        {
            try
            {
                List<Zbor> list = this.flyRepository.FlyList();

                if (list == null)
                {
                    this.searchFly.mesajListaGoala();
                    return null;
                }
                else
                {
                    return list;
                }
            }
            catch (Exception e)
            {
                this.searchFly.mesajExceptie(e.ToString());
                return null;
            }
        }
        private void cumparaBilet()
        {

        }
        private bool validInformation()
        {
            string aeroport = searchFly.GetFrom();
            string destinatie = searchFly.GetTo();
            string dataPlecare = searchFly.GetDataPlecare();
            string dataIntoarcere = searchFly.GetDataIntoarcere();
            string nrPasageri = searchFly.GetNumarPasageri();
            int pasageri = int.Parse(nrPasageri);

            if (aeroport == null || aeroport.Length == 0)
            {
                this.searchFly.mesajAeroportInvalid();
                return false;
            }

            if (destinatie == null || destinatie.Length == 0)
            {
                this.searchFly.mesajDestinatieInvalida();
                return false;
            }

            if (dataPlecare == null || dataPlecare.Length == 0)
            {
                this.searchFly.mesajDataPlecareInvalida();
                return false;
            }

            if (dataIntoarcere == null || dataIntoarcere.Length == 0)
            {
                this.searchFly.mesajDataRevenireInvalida();
                return false;
            }

            if (pasageri < 0)
            {
                this.searchFly.mesajNrPasageriInvalid();
                return false;
            }

            return true;
        }

        private void reset()
        {
            this.set.setDestinatie("");
            this.set.SetAeroport("");
            this.set.setDataPlecare("");
            this.set.setDataRevenire("");
            this.set.setNumarPasageri("");
        }
    }
}
