﻿using Aeroport.Model.Repository;
using Aeroport.Model;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Aeroport.Presenter
{
    class SchimbaParolaPresenter 
    {
        private ISchimbaParola schimbaParola;
        private UserRepository userRep;
        public SchimbaParolaPresenter(ISchimbaParola schimbaParola)
        {
            this.schimbaParola = schimbaParola;
            this.userRep = new UserRepository();
        }

        public void updateParola()
        {
            bool exista = this.userRep.UtilizatorExista(schimbaParola.getUtilizator());
            if(exista)
            {
                bool schimba = this.userRep.updateParola(schimbaParola.getUtilizator(), schimbaParola.getParola());
                if (schimba)
                {
                    this.schimbaParola.Succes();
                    this.schimbaParola.setParola("");
                    this.schimbaParola.setUtilizator("");
                }
                else
                {
                    this.schimbaParola.Esec();
                    this.schimbaParola.setParola("");
                    this.schimbaParola.setUtilizator("");
                }
            }
            else
            {
                this.schimbaParola.mesajNuExistaUtilizator();
                this.schimbaParola.setParola("");
                this.schimbaParola.setUtilizator("");
            }
        }
    }
}
