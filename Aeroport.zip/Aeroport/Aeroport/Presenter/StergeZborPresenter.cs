﻿using Aeroport.Model.Repository;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Presenter
{
    public class StergeZborPresenter<I1>
        where I1 : IstergeZbor
    {
        private I1 sterge;
        private ZborRepository flyRepository;
        public StergeZborPresenter(I1 sterge)
        {
            this.sterge = sterge;
            this.flyRepository = new ZborRepository();
        }
        public void deleteFly()
        {
            try
            {
                string numarZbor = this.getNumarZbor();
                int nrZbor = int.Parse(numarZbor);

                bool z = this.flyRepository.DeleteFly(nrZbor);

                if (z)
                {
                    this.sterge.mesajStergereSucces();
                    this.res();
                }
                else
                {
                    this.sterge.mesajStergereEsec();
                    this.res();
                }
            }
            catch (Exception ex)
            {
                this.sterge.mesajExceptie(ex.ToString());
            }
        }

        private string getNumarZbor()
        {
            string nrZbor = sterge.GetNumarZbor();
            int numarZbor = int.Parse(nrZbor);

            if (numarZbor < 0)
            {
                this.sterge.mesajNrZborInvalid();
                return "";
            }

            return nrZbor;
        }

        private void res()
        {
            this.sterge.SetNumarZbor("");
        }
    }
}
