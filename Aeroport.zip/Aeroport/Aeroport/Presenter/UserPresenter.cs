﻿using Aeroport.Model.Repository;
using Aeroport.Model;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using static Aeroport.ListaUseri;

namespace Aeroport.Presenter
{
    public class UserPresenter
    {
        private IadaugaUser adaugaUser;
        private UserRepository userRepository;
        public UserPresenter(IadaugaUser adaugaUser)
        {
            this.adaugaUser = adaugaUser;
            this.userRepository = new UserRepository();
        }
        public void AddUser()
        {
            try
            {
                User u = this.validInformation();
                if (u != null)
                {
                    bool result = this.userRepository.AddUser(u);
                    if (result)
                    {
                        this.adaugaUser.mesajSucces();
                        this.resetFlyControls();
                    }
                    else
                    {
                        this.adaugaUser.mesajEsec();
                    }
                }
            }
            catch (Exception ex)
            {
                this.adaugaUser.mesajEsec();
            }
        }

        public void deleteUser()
        {
            try
            {
                string id = this.getID();
                bool z = this.userRepository.DeleteUser(id);

                if (z)
                {
                    this.adaugaUser.mesajStergereSucces();
                }
                else
                {
                    this.adaugaUser.mesajStergereEsec();
                }
            }
            catch (Exception ex)
            {
                this.adaugaUser.mesajExceptie(ex.ToString());
            }
        }
        public void UpdateUser()
        {
            string utilizator = adaugaUser.getUtilizator();
            string parola = adaugaUser.getParola();
            string tipUser = adaugaUser.getTipUtilizator();
            string id = adaugaUser.getID();

            try
            {
                // schimbam utilizator
                if (!utilizator.Equals("") && parola.Equals("") && tipUser.Equals(""))
                {
                    bool result = this.userRepository.UpdateUtilizator(id.ToString(), utilizator);
                    this.adaugaUser.mesajSuccesModificare();
                    return;
                }

                //schimbam parola 
                if (utilizator.Equals("") && !parola.Equals("") && tipUser.Equals(""))
                {
                    bool result = this.userRepository.UpdateParola(id.ToString(), parola);
                    this.adaugaUser.mesajSuccesModificare();
                    return;
                }

                //schimbam durata tipUser
                if (utilizator.Equals("") && parola.Equals("") && !tipUser.Equals(""))
                {
                    bool result = this.userRepository.UpdateTipUser(id.ToString(), tipUser);
                    this.adaugaUser.mesajSuccesModificare();
                    return;
                }

                //schimbam utilizator, parola
                if (!utilizator.Equals("") && !parola.Equals("") && tipUser.Equals(""))
                {
                    bool result = this.userRepository.UpdateUtilizatorParola(utilizator, parola, id.ToString());
                    this.adaugaUser.mesajSuccesModificare();
                    return;
                }

                //schimbam utilizator, tipUser
                if (!utilizator.Equals("") && parola.Equals("") && !tipUser.Equals(""))
                {
                    bool result = this.userRepository.UpdateUtilizatorTipUser(utilizator, tipUser, id.ToString());
                    this.adaugaUser.mesajSuccesModificare();
                    return;
                }

                //schimbam parola, tipUser
                if (utilizator.Equals("") && !parola.Equals("") && !tipUser.Equals(""))
                {
                    bool result = this.userRepository.UpdateParolaTipUser(parola, tipUser, id.ToString());
                    this.adaugaUser.mesajSuccesModificare();
                    return;
                }

                //schibam tot
                if (!utilizator.Equals("") && !parola.Equals("") && !tipUser.Equals(""))
                {
                    bool result = this.userRepository.UpdateAll(utilizator, parola, tipUser, id.ToString());
                    this.adaugaUser.mesajSuccesModificare();
                    return;
                }
            }
            catch (Exception exception)
            {
                this.adaugaUser.mesajExceptie(exception.ToString());
            }
        }
        public string getID()
        {
            string id = adaugaUser.getID();

            return id;
        }
        private User validInformation()
        {
            string utilizator = adaugaUser.getUtilizator();
            string parola = adaugaUser.getParola();
            string tipUser = adaugaUser.getTipUtilizator();
            string id = "";

            if (utilizator == null || utilizator.Length == 0)
            {
                this.adaugaUser.mesajUtilizatorInvalid();
                return null;
            }

            if (parola == null || parola.Length == 0)
            {
                this.adaugaUser.mesajParolaInvalida();
                return null;
            }         
            
            if (tipUser == null || tipUser.Length == 0)
            {
                this.adaugaUser.mesajTipUserInvalida();
                return null;
            }

            return new User((string) utilizator, (string) parola, (string) tipUser, (string) id);
        }

        public List<User> allUsers()
        {
            try
            {
                List<User> list = this.userRepository.UsersList();

                if (list == null)
                {
                    this.adaugaUser.mesajListaGoala();
                    return null;
                }
                else
                {
                    return list;
                }
            }
            catch (Exception e)
            {
                this.adaugaUser.mesajExceptie(e.ToString());
                return null;
            }
        }

        public void afisareLista()
        {
            List<User> users = new List<User>();
            users = this.allUsers();

            int counter = users.Count;
            int i = 0;
            while (counter > 0)
            {
                DataGrid dg = this.adaugaUser.getGrid();
                UserGrid userss = new UserGrid();
                User row = users[i];

                userss.id = row.Id;
                userss.utilizator = row.Utilizator;
                userss.parola = row.Parola;
                userss.tipUser = row.TipUser; 

                dg.Items.Add(userss);
                counter--; i++;
            }
        }
        private void resetFlyControls()
        {
            this.adaugaUser.setUtilizator("");
            this.adaugaUser.setParola("");
            this.adaugaUser.setTipUtilizator("");
            this.adaugaUser.SetId(0);
        }   
    }
}
