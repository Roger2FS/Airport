﻿using Aeroport.Model.Repository;
using Aeroport.Model;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Aeroport.ListaBilete;
using System.Windows.Controls;

namespace Aeroport.Presenter
{
    public class BiletPresenter
    {
        private IcumparaBilet adaugaBilet;
        private BiletRepository ticketRepository;
        public BiletPresenter(IcumparaBilet adaugabilet)
        {
            this.adaugaBilet = adaugabilet;
            this.ticketRepository = new BiletRepository();
        }
        public void AddTicket()
        {
            try
            {
                bool result = this.ticketRepository.AddBilet();
                if (result)
                {
                    this.adaugaBilet.mesajSucces();
                }
                else
                {
                    this.adaugaBilet.mesajEsec();
                }
            }
            catch (Exception ex)
            {
                this.adaugaBilet.mesajEsec();
            }
        }
        public string getID()
        {
            return adaugaBilet.getID();
        }
        private Bilet validInformation()
        {
            string idZbor = this.ticketRepository.getIdZbor();
            string idUser = this.ticketRepository.getIdUser();

            int IDZbor = int.Parse(idZbor);
            int IDUser = int.Parse(idUser);

            if(IDZbor < 0)
            {
                this.adaugaBilet.mesajIDZborInvalid();
                return null;
            }

            if (IDZbor < 0)
            {
                this.adaugaBilet.mesajIDUserInvalid();
                return null;
            }

            return new Bilet("",(string)idZbor,(string)idUser,"");
        }

        public List<Bilet> allTickets()
        {
            try
            {
                List<Bilet> list = this.ticketRepository.FlyList();

                if (list == null)
                {
                    this.adaugaBilet.mesajListaGoala();
                    return null;
                }
                else
                {
                    return list;
                }
            }
            catch (Exception e)
            {
                this.adaugaBilet.mesajExceptie(e.ToString());
                return null;
            }
        }

        public void afisareLista()
        {
            List<Bilet> bilete = new List<Bilet>();
            bilete = this.allTickets();

            int counter = bilete.Count;
            int i = 0;
            while (counter > 0)
            {
                DataGrid dt = this.adaugaBilet.getGrid();
                BiletGrid tickets = new BiletGrid();
                Bilet row = bilete[i];

                tickets.id = row.id;
                tickets.idZbor = row.IdZbor;
                tickets.idUser = row.IdUser;
                tickets.numarBilete = row.NumarBilete;

                dt.Items.Add(tickets);
                counter--; i++;
            }
        }
    }
}
