﻿using Aeroport.Model;
using Aeroport.Model.Repository;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Aeroport.Presenter
{
    public class ListaUserPresenter
    {
        private IListaUser listaUseri;
        private UserRepository userRepository;

        public ListaUserPresenter(IListaUser listaUseri)
        {
            this.listaUseri = listaUseri;
            this.userRepository = new UserRepository();
        }
        public List<User> allUsers()
        {
            try
            {
                List<User> list = this.userRepository.UsersList();

                if (list == null)
                {
                    this.listaUseri.mesajListaGoala();
                    return null;
                }
                else
                {
                    return list;
                }
            }
            catch (Exception e)
            {
                this.listaUseri.mesajExceptie(e.ToString());
                return null;
            }
        }

        public void afisareLista()
        {
            List<User> users = new List<User>();
            users = this.allUsers();

            int counter = users.Count;
            int i = 0;
            while (counter > 0)
            {
                DataGrid dg = this.listaUseri.getGrid();
                UserGrid userss = new UserGrid();
                User row = users[i];

                userss.id = row.Id;
                userss.utilizator = row.Utilizator;
                userss.parola = row.Parola;
                userss.tipUser = row.TipUser;

                dg.Items.Add(userss);
                counter--; i++;
            }
        }
    }
}
