﻿using Aeroport.Model.Repository;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Presenter
{
    public class CumparaBiletPresenter
    {
        private IcumparaBilet adaugaBilet;
        private BiletRepository ticketRepository;
        public CumparaBiletPresenter(IcumparaBilet adaugabilet)
        {
            this.adaugaBilet = adaugabilet;
            this.ticketRepository = new BiletRepository();
        }
        public void AddTicket()
        {
            try
            {
                bool result = this.ticketRepository.AddBilet();
                if (result)
                {
                    this.adaugaBilet.mesajSucces();
                }
                else
                {
                    this.adaugaBilet.mesajEsec();
                }
            }
            catch (Exception ex)
            {
                this.adaugaBilet.mesajEsec();
            }
        }
    }
}
