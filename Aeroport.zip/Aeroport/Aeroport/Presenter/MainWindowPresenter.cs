﻿using Aeroport.Model.Repository;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aeroport.Presenter
{
    public class MainWindowPresenter
    {
        private ImainWindow main;
        private UserRepository userRep;
        public MainWindowPresenter(ImainWindow main)
        {
            this.main = main;
            this.userRep = new UserRepository();
        }

        public void logIn()
        {
            string tipUtilizator = this.userRep.getTipUtilizator(this.main.getUtilizator(),this.main.getParola());

            if (tipUtilizator.Equals(""))
            {
                main.mesajUtilizatorParolaNuExista();
            }
            else
            {
                if (tipUtilizator.Equals("Calator"))
                {
                    FereastraClient fereastraClient = new FereastraClient();
                    this.updateSantinela();
                    fereastraClient.Show();
                }
                else if (tipUtilizator.Equals("Angajat"))
                {
                    FereastraAngajat angajat = new FereastraAngajat();
                    this.updateSantinela2();
                    angajat.Show();
                }
                else if (tipUtilizator.Equals("Administrator"))
                {
                    FereastraAdministrator fereastra = new FereastraAdministrator();
                    this.updateSantinela2();
                    fereastra.Show();
                }
            }
        }

        public void updateSantinela()
        {
            this.userRep.updateSantinela();
        }

        public void updateSantinela2()
        {
            this.userRep.updateSantinela2();
        }
    }
}
