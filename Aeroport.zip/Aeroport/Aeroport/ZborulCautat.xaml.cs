﻿using Aeroport.Model;
using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for ZborulCautat.xaml
    /// </summary>
    public partial class ZborulCautat : Window, IadaugaZbor, interfataComuna
    {
        private ZborPresenter<IadaugaZbor, interfataComuna> zborPresenter;
        public ZborulCautat()
        {
            InitializeComponent();
            this.zborPresenter = new ZborPresenter<IadaugaZbor, interfataComuna>(this,this);
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Zbor zbors;
            ZborGrid flyes = new ZborGrid();

            gridView1.Items.Add(flyes);
        }

        public void mesajAeroportInvalid()
        {
            MessageBox.Show("Aeroportul este invalid!");
        }

        public void mesajDateInvalide()
        {
            MessageBox.Show("Date invalide!");
        }

        public void mesajDestinatieInvalida()
        {
            MessageBox.Show("Destinatia este invalida!");
        }

        public void mesajDurataInvalida()
        {
            MessageBox.Show("Durata este invalida!");
        }

        public void mesajEsec()
        {
            MessageBox.Show("Zborul nu a putut fi sters!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex);
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista de zboruri este goala!");
        }

        public void mesajModalitateInvalida()
        {
            MessageBox.Show("Modalitatea este invalida!");
        }

        public void mesajNrZborInvalid()
        {
            MessageBox.Show("Numar zbor invalid!");
        }

        public void mesajPretInvalid()
        {
            MessageBox.Show("Pretul este invalid!");
        }

        public void mesajSucces()
        {
            MessageBox.Show("Zborul a fost sters cu succes!");
        }
        public void mesajStergereSucces()
        {
            MessageBox.Show("Zborul a fost sters!");
        }

        public void mesajStergereEsec()
        {
            MessageBox.Show("Zborul nu a putut fi sters!");
        }
        public void mesajSuccesModificare()
        {
            MessageBox.Show("Modificarea s-a efectutat cu succes!");
        }

        public void mesajEsecModificare()
        {
            MessageBox.Show("Modificare nu a putut fi efectuata!");
        }

        public void mesajNrPasageriInvalid()
        {
            MessageBox.Show("Numar pasageri invalid!");
        }

        public void mesajDataPlecareInvalida()
        {
            MessageBox.Show("Data plecare invalida!");
        }

        public void mesajDataRevenireInvalida()
        {
            MessageBox.Show("Data revenire invalida!");
        }

        public void mesajGasireSucces()
        {
            MessageBox.Show("Zborul a fost gasit!");
        }

        public void mesajGasireEsec()
        {
            MessageBox.Show("Zborul nu a fost gasit!");
        }
        public string GetAeroport()
        {
            throw new NotImplementedException();
        }

        public void SetAeroport(string aeroport)
        {
            throw new NotImplementedException();
        }

        public string GetDestinatie()
        {
            throw new NotImplementedException();
        }

        public void setDestinatie(string destinatie)
        {
            throw new NotImplementedException();
        }

        public string GetPret()
        {
            throw new NotImplementedException();
        }

        public void SetPret(string pret)
        {
            throw new NotImplementedException();
        }

        public string GetNumarZbor()
        {
            throw new NotImplementedException();
        }

        public void SetNumarZbor(string numarZbor)
        {
            throw new NotImplementedException();
        }

        public string GetDurataZbor()
        {
            throw new NotImplementedException();
        }

        public void SetDurataZbor(string durataZbor)
        {
            throw new NotImplementedException();
        }

        public string GetModalitate()
        {
            throw new NotImplementedException();
        }

        public void SetModalitate(string modalitate)
        {
            throw new NotImplementedException();
        }

        public string getDataPlecare()
        {
            throw new NotImplementedException();
        }

        public string getDataRevenire()
        {
            throw new NotImplementedException();
        }

        public void setDataPlecare(string value)
        {
            throw new NotImplementedException();
        }

        public void setDataRevenire(string value)
        {
            throw new NotImplementedException();
        }

        public string getLocuri()
        {
            throw new NotImplementedException();
        }

        public void setLocuri(string nrLocuri)
        {
            throw new NotImplementedException();
        }

        public string GetFrom()
        {
            throw new NotImplementedException();
        }

        public string GetTo()
        {
            throw new NotImplementedException();
        }

        public string GetDataPlecare()
        {
            throw new NotImplementedException();
        }

        public string GetDataIntoarcere()
        {
            throw new NotImplementedException();
        }

        public string GetNumarPasageri()
        {
            throw new NotImplementedException();
        }

        public void setNumarPasageri(string pasageri)
        {
            throw new NotImplementedException();
        }

        public DataGrid getGrid()
        {
            throw new NotImplementedException();
        }
    }
}
