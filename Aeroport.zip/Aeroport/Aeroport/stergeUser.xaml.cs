﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for stergeUser.xaml
    /// </summary>
    public partial class StergeUser : Window, IstergeUser
    {
        private StergeUserPresenter userPres;
        public StergeUser()
        {
            InitializeComponent();
            this.userPres = new StergeUserPresenter(this);
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.userPres.deleteUser();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ActiuniAdministrator admin = new ActiuniAdministrator();
            this.Close();
            admin.Show();
        }

        public string getID()
        {
            return idUser.Text; 
        }

        public void mesajEsec()
        {
            MessageBox.Show("Userul nu a putut fi sters!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajIdInvalid()
        {
            MessageBox.Show("ID INVALID!");
        }
        public void mesajListaGoala()
        {
            MessageBox.Show("Lista goala!");
        }

        public void mesajParolaInvalida()
        {
            MessageBox.Show("Parola invalida!");
        }

        public void mesajStergereEsec()
        {
            MessageBox.Show("Userul nu a putut fi sters!");
        }

        public void mesajStergereSucces()
        {
            MessageBox.Show("Userul a fost sters!");
        }

        public void mesajSucces()
        {
            MessageBox.Show("Userul a fost sters!");
        }

        public void mesajSuccesModificare()
        {
            MessageBox.Show("Modificare efectuata cu succes!");
        }

        public void mesajTipUserInvalida()
        {
            MessageBox.Show("Tip user invalid!");
        }

        public void mesajUtilizatorInvalid()
        {
            MessageBox.Show("Utilizator invalid!");
        }
    }
}
