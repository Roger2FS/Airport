﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for FereastraClient.xaml
    /// </summary>
    public partial class FereastraClient : Window, interfataComuna, setters
    {
        SearchFlyPresenter fly;
        public FereastraClient()
        {
            InitializeComponent();
            this.fly = new SearchFlyPresenter(this,this);
        }

        public string GetDataIntoarcere()
        {
            return sosireBTN.Text;    
        }

        public string GetDataPlecare()
        {
            return plecareBTN.Text;  
        }

        public string GetFrom()
        {
            return fromBTN.Text; 
        }

        public string GetNumarPasageri()
        {
            return nrPasageri.Text;
        }

        public string GetTo()
        {
            return toBTN.Text; 
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.fly.getSearchedZbor();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Zboruri zboruri = new Zboruri();
            this.Close();
            zboruri.Show();
        }
        public void mesajAeroportInvalid()
        {
            MessageBox.Show("Aeroport invalid!");
        }

        public void mesajDataPlecareInvalida()
        {
            MessageBox.Show("Data plecare invalida!");
        }

        public void mesajDataRevenireInvalida()
        {
            MessageBox.Show("Data revenire invalida!");
        }

        public void mesajDestinatieInvalida()
        {
            MessageBox.Show("Destinatie invalida!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajGasireEsec()
        {
            MessageBox.Show("Zborul nu a fost gasit!");
        }

        public void mesajGasireSucces()
        {
            MessageBox.Show("Zborul a fost gasit!");
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista este goala!");
        }

        public void mesajNrPasageriInvalid()
        {
            MessageBox.Show("Numarul de pasageri este invalid!");
        }

        public void SetAeroport(string aeroport)
        {
            this.fromBTN.Text = aeroport;
        }

        public void setDataPlecare(string dataPlecare)
        {
            this.plecareBTN.Text = dataPlecare;
        }

        public void setDataRevenire(string dataRevenire)
        {
            this.sosireBTN.Text = dataRevenire;
        }

        public void setDestinatie(string destinatie)
        {
            this.toBTN.Text = destinatie;
        }

        public void setNumarPasageri(string nrPasageri)
        {
            this.nrPasageri.Text = nrPasageri;
        }
    }
}
