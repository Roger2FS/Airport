﻿using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for actiuniAdministrator.xaml
    /// </summary>
    public partial class ActiuniAdministrator : Window 
    {
        public ActiuniAdministrator()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AdaugaUser user = new AdaugaUser();
            this.Close();
            user.Show();    
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            StergeUser sterge = new StergeUser();
            this.Close();
            sterge.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ModificaUser modifica = new ModificaUser();
            this.Close();
            modifica.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            FereastraAdministrator fereastraAdministrator = new FereastraAdministrator();
            this.Close();
            fereastraAdministrator.Show();
        }
    }
}
