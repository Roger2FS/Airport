﻿using Aeroport.Presenter;
using Aeroport.View;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, ImainWindow
    {
        private MainWindowPresenter mWP;
        public MainWindow()
        {
            InitializeComponent();
            this.mWP = new MainWindowPresenter(this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.mWP.logIn();
            this.Close();
        }

        public string getUtilizator()
        {
            return this.utilizatorLog.Text; 
        }
        
        public void setUtilizator(string utilizator)
        {
            this.utilizatorLog.Text = utilizator;
        }

        public string getParola()
        {
            return this.parolaLog.Password.ToString(); 
        }

        public void setParola(string parola)
        {
            this.parolaLog.Password = parola;
        }

        public void mesajUtilizatorParolaNuExista()
        {
            MessageBox.Show("Utilizator sau parola invalide!");
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Register reg = new Register();
            this.Close();
            reg.Show();
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ParolaNoua parolaNoua = new ParolaNoua();
            this.Close();
            parolaNoua.Show();
        }
        
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            this.mWP.updateSantinela();

            FereastraClient fereastraClient = new FereastraClient();
            this.Close();
            fereastraClient.Show();
        }

        private void utilizatorLog_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
