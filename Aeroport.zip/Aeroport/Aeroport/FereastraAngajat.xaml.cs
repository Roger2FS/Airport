﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for FereastraAngajat.xaml
    /// </summary>
    public partial class FereastraAngajat : Window, interfataComuna, setters
    {
        SearchFlyPresenter fly;
        public FereastraAngajat()
        {
            InitializeComponent();
            this.fly = new SearchFlyPresenter(this,this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.fly.getSearchedZbor();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Zboruri zboruri = new Zboruri();
            this.Close();
            zboruri.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            ActiuniAngajat actiuniAngajat = new ActiuniAngajat();
            this.Close();
            actiuniAngajat.Show();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            ListaBilete listaBilete = new ListaBilete();
            this.Close();
            listaBilete.Show();
        }
        public string GetFrom()
        {
            return fromBTN.Text;
        }
        public string GetTo()
        {
            return toBTN.Text;
        }
        public string GetDataPlecare()
        {
            return dataPlecare.Text;
        }
        public string GetDataIntoarcere()
        {
            return dataSosire.Text; 
        }
        public string GetNumarPasageri()
        {
            return nrPasageri.Text;
        }

        public void mesajAeroportInvalid()
        {
            MessageBox.Show("Aeroport invalid!");
        }

        public void mesajDestinatieInvalida()
        {
            MessageBox.Show("Destinatie invalida!");
        }

        public void mesajNrPasageriInvalid()
        {
            MessageBox.Show("Numar pasageri invalid!");
        }

        public void mesajDataPlecareInvalida()
        {
            MessageBox.Show("Data plecare invalida!");
        }

        public void mesajDataRevenireInvalida()
        {
            MessageBox.Show("Data revenire invalida!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista este goala!");
        }

        public void mesajGasireSucces()
        {
            MessageBox.Show("Zborul a fost gasit!");
        }

        public void mesajGasireEsec()
        {
            MessageBox.Show("Zborul nu a fost gasit!");
        }

        public void setDestinatie(string destinatie)
        {
            this.toBTN.Text = destinatie;
        }

        public void SetAeroport(string aeroport)
        {
            this.fromBTN.Text = aeroport;
        }

        public void setDataPlecare(string dataPlecare)
        {
            this.dataPlecare.Text = dataPlecare;
        }

        public void setDataRevenire(string dataRevenire)
        {
            this.dataSosire.Text = dataRevenire;
        }

        public void setNumarPasageri(string nrPasageri)
        {
            this.nrPasageri.Text = nrPasageri;
        }
    }
}
