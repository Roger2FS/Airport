﻿using Aeroport.Model;
using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for ListaUseri.xaml
    /// </summary>
    public partial class ListaUseri : Window, IListaUser
    {
        private ListaUserPresenter userP;
        public ListaUseri()
        {
            InitializeComponent();
            this.userP = new ListaUserPresenter(this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.userP.afisareLista();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            FereastraAdministrator fereastraClient = new FereastraAdministrator();
            this.Close();
            fereastraClient.Show();
        }
        public DataGrid getGrid()
        {
            return this.gridView1 as DataGrid;
        }
        public void mesajAeroportInvalid()
        {
            MessageBox.Show("Aeroport invalid!");
        }

        public void mesajDestinatieInvalida()
        {
            MessageBox.Show("Destinatie invalida!");
        }

        public void mesajNrPasageriInvalid()
        {
            MessageBox.Show("Numar pasageri invalid!");
        }

        public void mesajDataPlecareInvalida()
        {
            MessageBox.Show("Data plecare invalida!");
        }

        public void mesajDataRevenireInvalida()
        {
            MessageBox.Show("Data revenire invalida!");
        }

        public void mesajEsec()
        {
            MessageBox.Show("Eroare!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajIdInvalid()
        {
            MessageBox.Show("ID invalid!");
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista goala!");
        }

        public void mesajParolaInvalida()
        {
            MessageBox.Show("Parola invalida!");
        }

        public void mesajStergereEsec()
        {
            MessageBox.Show("Stergerea nu a avut loc!");
        }

        public void mesajStergereSucces()
        {
            MessageBox.Show("Stergere cu succes!");
        }

        public void mesajSucces()
        {
            MessageBox.Show("Succes!");
        }

        public void mesajSuccesModificare()
        {
            MessageBox.Show("Modificare cu succes!");
        }

        public void mesajTipUserInvalida()
        {
            MessageBox.Show("Tip user invalid!");
        }

        public void mesajUtilizatorInvalid()
        {
            MessageBox.Show("Utilizator invalid!");
        }
    }
}
