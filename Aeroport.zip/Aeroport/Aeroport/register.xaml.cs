﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for register.xaml
    /// </summary>
    public partial class Register : Window, IRegister
    {
        private RegisterPresenter reg;
        public Register()
        {
            InitializeComponent();
            this.reg = new RegisterPresenter(this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.reg.creareCont();
            this.Close();
        }

        private void utilizatorReg_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        public string getUtilizator()
        {
            return this.utilizatorReg.Text;
        }

        public void setUtilizator(string utilizator)
        {
            this.utilizatorReg.Text = utilizator;
        }

        public string getParola()
        {
            return this.parolaReg.Password.ToString();
        }

        public void setParola(string parola)
        {
            this.parolaReg.Password = parola;
        }

        public void mesajSucces()
        {
            MessageBox.Show("Contul a fost realizat cu succes!");
        }

        public void mesajEsec()
        {
            MessageBox.Show("Contul nu a putut fi realizat!");
        }

        public void mesajUtilizatorExista()
        {
            MessageBox.Show("Parola sau utilizator existente!");
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.Show();
        }
    }
}
