﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for stergeZbor.xaml
    /// </summary>
    public partial class StergeZbor : Window, IstergeZbor
    {
        private StergeZborPresenter<StergeZbor> zborPresenter;
        public StergeZbor()
        {
            InitializeComponent();
            this.zborPresenter = new StergeZborPresenter<StergeZbor>(this);
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.zborPresenter.deleteFly();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ActiuniAngajat actiuniAngajat = new ActiuniAngajat();
            this.Close();
            actiuniAngajat.Show();
        }

        public string GetNumarZbor()
        {
            return nrZbor.Text;
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex);
        }

        public void mesajStergereSucces()
        {
            MessageBox.Show("Zborul a fost sters!");
        }

        public void mesajStergereEsec()
        {
            MessageBox.Show("Zborul nu a putut fi sters!");
        }
        public void SetNumarZbor(string numarZbor)
        {
            this.nrZbor.Text = numarZbor;
        }

        public void mesajNrZborInvalid()
        {
            MessageBox.Show("Numar zbor introdus invalid!");
        }
    }
}
