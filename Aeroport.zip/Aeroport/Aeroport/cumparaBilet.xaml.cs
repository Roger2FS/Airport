﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for cumparaBilet.xaml
    /// </summary>
    public partial class CumparaBilet : Window, IcumparaBilet
    {
        private BiletPresenter ticketPresenter;
        public CumparaBilet()
        {
            InitializeComponent();
            this.ticketPresenter = new BiletPresenter(this);
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.ticketPresenter.AddTicket();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public void mesajEsec()
        {
            MessageBox.Show("Nu a putut fi achizitionat biletul pentru acest zbor!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajIDUserInvalid()
        {
            MessageBox.Show("ID user invalid!");
        }

        public void mesajIDZborInvalid()
        {
            MessageBox.Show("ID zbor invalid!");
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista este goala!");
        }

        public void mesajSucces()
        {
            MessageBox.Show("Bilet achizitionat!");
        }

        public string getID()
        {
            throw new NotImplementedException();
        }

        public string getIdUser()
        {
            throw new NotImplementedException();
        }

        public string getIdZbor()
        {
            throw new NotImplementedException();
        }

        public DataGrid getGrid()
        {
            throw new NotImplementedException();
        }
    }
}
