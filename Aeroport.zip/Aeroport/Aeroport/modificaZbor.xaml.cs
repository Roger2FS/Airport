﻿using Aeroport.Presenter;
using Aeroport.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Aeroport
{
    /// <summary>
    /// Interaction logic for modificaZbor.xaml
    /// </summary>
    public partial class ModificaZbor : Window, IadaugaZbor, interfataComuna
    {
        private ZborPresenter<IadaugaZbor, interfataComuna> zborPresenter;
        public ModificaZbor()
        {
            InitializeComponent();
            this.zborPresenter = new ZborPresenter<IadaugaZbor, interfataComuna>(this, this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.zborPresenter.UpdateFly();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ActiuniAngajat actiuniAngajat = new ActiuniAngajat();
            this.Close();
            actiuniAngajat.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ActiuniAngajat actiuniAngajat = new ActiuniAngajat();
            this.Close();
            actiuniAngajat.Show();
        }

        public string GetDurataZbor()
        {
            return durata.Text;
        }

        public string GetFrom()
        {
            return aeroport.Text;
        }

        public string GetNumarZbor()
        {
            return nrZbor.Text;
        }

        public string GetPret()
        {
            return pret.Text;
        }

        public string GetTo()
        {
            return destinatie.Text;
        }

        public void mesajAeroportInvalid()
        {
            MessageBox.Show("Aeroport invalid!");
        }

        public void mesajDataPlecareInvalida()
        {
            MessageBox.Show("Data plecare invalida!");
        }

        public void mesajDataRevenireInvalida()
        {
            MessageBox.Show("Data revenire invalida!");
        }

        public void mesajDateInvalide()
        {
            MessageBox.Show("Date invalide!");
        }

        public void mesajDestinatieInvalida()
        {
            MessageBox.Show("Destinatie invalida!");
        }

        public void mesajDurataInvalida()
        {
            MessageBox.Show("Durata invalida");
        }

        public void mesajEsec()
        {
            MessageBox.Show("Modificarea nu a putut fi efectuata!");
        }

        public void mesajEsecModificare()
        {
            MessageBox.Show("Modificarea nu a putut fi efectuata!");
        }

        public void mesajExceptie(string ex)
        {
            MessageBox.Show(ex.ToString());
        }

        public void mesajGasireEsec()
        {
            MessageBox.Show("Zborul nu a putut fi gasit!");
        }

        public void mesajGasireSucces()
        {
            MessageBox.Show("Zborul a fost gasit!");
        }

        public void mesajListaGoala()
        {
            MessageBox.Show("Lista este goala!");
        }

        public void mesajModalitateInvalida()
        {
            MessageBox.Show("Modalitate invalida!");
        }

        public void mesajNrPasageriInvalid()
        {
            MessageBox.Show("Numar pasageri invalid!");
        }

        public void mesajNrZborInvalid()
        {
            MessageBox.Show("Numar zbor invalid");
        }

        public void mesajPretInvalid()
        {
            MessageBox.Show("Pret invalid!");
        }

        public void mesajStergereEsec()
        {
            MessageBox.Show("Stergerea nu a putut fi efectuata");
        }

        public void mesajStergereSucces()
        {
            MessageBox.Show("Stergere efectuata cu succes!");
        }

        public void mesajSucces()
        {
            MessageBox.Show("Modificare cu succes!");
        }

        public void mesajSuccesModificare()
        {
            MessageBox.Show("Modificare cu succes!");
        }

        public void SetAeroport(string aeroport)
        {
            this.aeroport.Text = aeroport;
        }

        public void setDestinatie(string destinatie)
        {
            this.destinatie.Text = destinatie;
        }

        public void SetNumarZbor(string numarZbor)
        {
            this.nrZbor.Text = numarZbor;
        }

        public void SetPret(string pret)
        {
            this.pret.Text = pret;
        }

        public void SetDurataZbor(string durataZbor)
        {
            this.durata.Text = durataZbor;
        }

        public void setDataPlecare(string value)
        {
            throw new NotImplementedException();
        }

        public void setDataRevenire(string value)
        {
            throw new NotImplementedException();
        }

        public void SetModalitate(string modalitate)
        {
            throw new NotImplementedException();
        }

        public string GetModalitate()
        {
            throw new NotImplementedException();
        }

        public string GetNumarPasageri()
        {
            throw new NotImplementedException();
        }

        public string GetDataPlecare()
        {
            throw new NotImplementedException();
        }

        public string GetDataIntoarcere()
        {
            throw new NotImplementedException();
        }

        public void setNumarPasageri(string pasageri)
        {
            throw new NotImplementedException();
        }

        public DataGrid getGrid()
        {
            throw new NotImplementedException();
        }
    }
}
